from aiogram.fsm.state import State, StatesGroup


class Onboarding(StatesGroup):
    choosing_country = State()
    choosing_region = State()


class TrackLink(StatesGroup):
    waiting_for_url = State()


class SearchProduct(StatesGroup):
    waiting_for_query = State()


class SetTarget(StatesGroup):
    waiting_for_price = State()
