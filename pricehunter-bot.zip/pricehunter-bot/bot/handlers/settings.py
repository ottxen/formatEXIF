from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext

from bot.database.models import Database
from bot.keyboards.inline import (
    main_menu_kb,
    countries_kb,
    COUNTRIES,
)
from bot.states.states import Onboarding

router = Router()


@router.callback_query(F.data == "menu:settings")
async def menu_settings(callback: CallbackQuery, db: Database):
    user = await db.get_user(callback.from_user.id)
    country = COUNTRIES.get(user.get("country"), "Not set") if user else "Not set"
    region = user.get("region") if user else None

    text = (
        "⚙️ <b>Settings</b>\n\n"
        f"📍 Country: <b>{country}</b>\n"
        f"📍 Region: <b>{region or 'Not set'}</b>\n\n"
        "You can change your location below."
    )

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="🌍 Change country / region", callback_data="settings:location")
    builder.button(text="⬅️ Main Menu", callback_data="menu:main")
    builder.adjust(1)

    await callback.message.edit_text(text, reply_markup=builder.as_markup())
    await callback.answer()


@router.callback_query(F.data == "settings:location")
async def change_location(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Onboarding.choosing_country)
    await callback.message.edit_text(
        "Select your country:",
        reply_markup=countries_kb(),
    )
    await callback.answer()
