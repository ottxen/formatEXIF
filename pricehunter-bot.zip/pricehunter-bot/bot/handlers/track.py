from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from bot.database.models import Database
from bot.keyboards.inline import main_menu_kb, back_to_main_kb, product_actions_kb
from bot.states.states import TrackLink, SetTarget
from bot.services.parser import parse_product

router = Router()


@router.callback_query(F.data == "menu:track")
async def menu_track(callback: CallbackQuery, state: FSMContext):
    await state.set_state(TrackLink.waiting_for_url)
    await callback.message.edit_text(
        "🔗 <b>Track by link</b>\n\n"
        "Send me a product URL from any supported store.\n\n"
        "Examples:\n"
        "• rozetka.com.ua\n"
        "• allo.ua\n"
        "• comfy.ua\n"
        "• amazon.de / amazon.com\n"
        "• allegro.pl\n\n"
        "Just paste the link here 👇",
        reply_markup=back_to_main_kb(),
    )
    await callback.answer()


@router.message(TrackLink.waiting_for_url)
async def process_url(message: Message, state: FSMContext, db: Database):
    url = message.text.strip() if message.text else ""

    if not url.startswith("http"):
        await message.answer(
            "⚠️ Please send a valid URL starting with http:// or https://",
            reply_markup=back_to_main_kb(),
        )
        return

    wait_msg = await message.answer("⏳ Fetching product info...")

    parsed = await parse_product(url)

    product_id = await db.add_product(
        user_id=message.from_user.id,
        url=url,
        title=parsed.title,
        price=parsed.price,
        currency=parsed.currency,
        store=parsed.store,
        image_url=parsed.image_url,
    )

    await state.clear()

    price_text = (
        f"<b>{parsed.price:.2f} {parsed.currency}</b>"
        if parsed.price is not None
        else "Price not detected"
    )

    text = (
        f"✅ <b>Product added to Watchlist!</b>\n\n"
        f"<b>{parsed.title}</b>\n"
        f"Store: {parsed.store}\n"
        f"Current price: {price_text}\n\n"
        f"I will notify you when the price drops.\n"
        f"You can also set a target price."
    )

    await wait_msg.edit_text(text, reply_markup=product_actions_kb(product_id))


@router.callback_query(F.data.startswith("target:"))
async def ask_target(callback: CallbackQuery, state: FSMContext):
    product_id = int(callback.data.split(":")[1])
    await state.set_state(SetTarget.waiting_for_price)
    await state.update_data(product_id=product_id)

    await callback.message.answer(
        "🎯 Send the target price (numbers only).\n"
        "Example: <code>499</code> or <code>1299.50</code>\n\n"
        "I will notify you when the price reaches this value or lower.",
    )
    await callback.answer()


@router.message(SetTarget.waiting_for_price)
async def set_target_price(message: Message, state: FSMContext, db: Database):
    data = await state.get_data()
    product_id = data.get("product_id")

    try:
        target = float(message.text.replace(",", ".").strip())
        if target <= 0:
            raise ValueError
    except (ValueError, TypeError):
        await message.answer("⚠️ Please send a valid positive number.")
        return

    await db.set_target_price(product_id, target)
    await state.clear()

    product = await db.get_product(product_id)
    await message.answer(
        f"✅ Target price set to <b>{target:.2f} {product.get('currency', 'UAH')}</b>\n"
        f"for <b>{product.get('title', 'product')}</b>.",
        reply_markup=main_menu_kb(),
    )


@router.callback_query(F.data.startswith("check:"))
async def check_now(callback: CallbackQuery, db: Database):
    product_id = int(callback.data.split(":")[1])
    product = await db.get_product(product_id)

    if not product or product["user_id"] != callback.from_user.id:
        await callback.answer("Product not found", show_alert=True)
        return

    await callback.answer("Checking...")
    parsed = await parse_product(product["url"])

    if parsed.price is not None:
        old = product["current_price"]
        await db.update_product_price(product_id, parsed.price)
        change = ""
        if old is not None:
            if parsed.price < old:
                change = f"\n📉 Dropped from {old:.2f}"
            elif parsed.price > old:
                change = f"\n📈 Raised from {old:.2f}"

        await callback.message.answer(
            f"🔄 <b>Updated</b>\n\n"
            f"{parsed.title}\n"
            f"Price: <b>{parsed.price:.2f} {parsed.currency}</b>{change}",
            reply_markup=product_actions_kb(product_id),
        )
    else:
        await callback.message.answer(
            "⚠️ Could not fetch the current price. Try again later.",
            reply_markup=product_actions_kb(product_id),
        )


@router.callback_query(F.data.startswith("remove:"))
async def ask_remove(callback: CallbackQuery):
    from bot.keyboards.inline import confirm_remove_kb

    product_id = int(callback.data.split(":")[1])
    await callback.message.edit_text(
        "Are you sure you want to remove this product from your Watchlist?",
        reply_markup=confirm_remove_kb(product_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_remove:"))
async def confirm_remove(callback: CallbackQuery, db: Database):
    product_id = int(callback.data.split(":")[1])
    ok = await db.deactivate_product(product_id, callback.from_user.id)

    if ok:
        await callback.message.edit_text(
            "🗑 Product removed from Watchlist.",
            reply_markup=main_menu_kb(),
        )
    else:
        await callback.answer("Could not remove product", show_alert=True)
    await callback.answer()
