from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

from bot.keyboards.inline import (
    categories_kb,
    subcategories_kb,
    items_kb,
    main_menu_kb,
    back_to_main_kb,
    CATEGORIES,
)
from bot.states.states import SearchProduct

router = Router()


@router.callback_query(F.data == "menu:categories")
async def menu_categories(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "📂 <b>Browse categories</b>\n\n"
        "Choose a category to start searching:",
        reply_markup=categories_kb(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("cat:"))
async def on_category(callback: CallbackQuery, state: FSMContext):
    cat_key = callback.data.split(":")[1]
    cat = CATEGORIES.get(cat_key)

    if not cat:
        await callback.answer("Unknown category", show_alert=True)
        return

    name = cat["name"] if isinstance(cat, dict) else cat
    await callback.message.edit_text(
        f"{name}\n\nChoose a subcategory:",
        reply_markup=subcategories_kb(cat_key),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sub:"))
async def on_subcategory(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    cat_key, sub_key = parts[1], parts[2]

    cat = CATEGORIES.get(cat_key, {})
    subs = cat.get("subs", {}) if isinstance(cat, dict) else {}
    sub = subs.get(sub_key)

    # If this subcategory has deeper items
    if isinstance(sub, dict) and "items" in sub:
        name = sub.get("name", sub_key)
        await callback.message.edit_text(
            f"{name}\n\nChoose what you need or type a product name:",
            reply_markup=items_kb(cat_key, sub_key),
        )
    else:
        # Go directly to search
        name = sub if isinstance(sub, str) else sub.get("name", sub_key)
        await state.set_state(SearchProduct.waiting_for_query)
        await state.update_data(category=cat_key, subcategory=sub_key, label=name)
        await callback.message.edit_text(
            f"🔍 <b>{name}</b>\n\n"
            "Type the product name you want to find:\n"
            "(e.g. <i>iPhone 15 case</i> or <i>Samsung Galaxy S24</i>)",
            reply_markup=back_to_main_kb(),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("item:"))
async def on_item(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    cat_key, sub_key, item_key = parts[1], parts[2], parts[3]

    # Build a readable label
    label = item_key.replace("_", " ").title()
    await state.set_state(SearchProduct.waiting_for_query)
    await state.update_data(category=cat_key, subcategory=sub_key, item=item_key, label=label)

    await callback.message.edit_text(
        f"🔍 <b>{label}</b>\n\n"
        "Type the product name or model you are looking for:\n"
        "(e.g. <i>Spigen iPhone 15</i> or <i>silicone case Samsung</i>)",
        reply_markup=back_to_main_kb(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("search:"))
async def on_search_button(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    cat_key, sub_key = parts[1], parts[2]
    await state.set_state(SearchProduct.waiting_for_query)
    await state.update_data(category=cat_key, subcategory=sub_key)

    await callback.message.edit_text(
        "🔍 Type the product name you want to find:",
        reply_markup=back_to_main_kb(),
    )
    await callback.answer()


@router.message(SearchProduct.waiting_for_query)
async def process_search_query(message: Message, state: FSMContext):
    query = message.text.strip() if message.text else ""
    data = await state.get_data()
    label = data.get("label", "product")

    await state.clear()

    # MVP: we don't have a full multi-store search engine yet.
    # Guide the user to paste a link instead / give tips.
    text = (
        f"🔎 You searched for: <b>{query}</b>\n"
        f"Category: {label}\n\n"
        "Full multi-store search is being improved.\n\n"
        "<b>Best way right now:</b>\n"
        "1. Open Rozetka / Allo / Comfy / Amazon\n"
        "2. Find the product you want\n"
        "3. Copy the product link\n"
        "4. Come back and use <b>🔗 Track by link</b>\n\n"
        "I will then watch the price and notify you on drops."
    )

    await message.answer(text, reply_markup=main_menu_kb())
