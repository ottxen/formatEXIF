from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext

from bot.database.models import Database
from bot.keyboards.inline import (
    countries_kb,
    regions_kb,
    main_menu_kb,
    COUNTRIES,
)
from bot.states.states import Onboarding

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, db: Database):
    await db.upsert_user(
        user_id=message.from_user.id,
        username=message.from_user.username,
        full_name=message.from_user.full_name,
    )
    user = await db.get_user(message.from_user.id)

    if user and user.get("country"):
        await message.answer(
            f"👋 Welcome back!\n\n"
            f"📍 Location: {COUNTRIES.get(user['country'], user['country'])}"
            f"{' → ' + user['region'] if user.get('region') else ''}\n\n"
            f"What would you like to do?",
            reply_markup=main_menu_kb(),
        )
        await state.clear()
        return

    await state.set_state(Onboarding.choosing_country)
    await message.answer(
        "👋 Welcome to <b>PriceHunter</b>!\n\n"
        "I help you track product prices and find the best deals.\n\n"
        "First, please select your country:",
        reply_markup=countries_kb(),
    )


@router.callback_query(F.data.startswith("country:"))
async def on_country(callback: CallbackQuery, state: FSMContext, db: Database):
    country_code = callback.data.split(":")[1]
    await state.update_data(country=country_code)
    await state.set_state(Onboarding.choosing_region)

    await callback.message.edit_text(
        f"Great! You selected <b>{COUNTRIES.get(country_code, country_code)}</b>.\n\n"
        "Now choose your region (helps with delivery options):",
        reply_markup=regions_kb(country_code),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("region:"))
async def on_region(callback: CallbackQuery, state: FSMContext, db: Database):
    region = callback.data.split(":", 1)[1]
    data = await state.get_data()
    country = data.get("country", "UA")

    await db.set_user_location(callback.from_user.id, country, region)
    await state.clear()

    await callback.message.edit_text(
        f"✅ Location set: <b>{COUNTRIES.get(country, country)} → {region}</b>\n\n"
        "What would you like to do?",
        reply_markup=main_menu_kb(),
    )
    await callback.answer()


@router.callback_query(F.data == "back:countries")
async def back_to_countries(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Onboarding.choosing_country)
    await callback.message.edit_text(
        "Please select your country:",
        reply_markup=countries_kb(),
    )
    await callback.answer()


@router.callback_query(F.data == "menu:main")
async def menu_main(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "🏠 <b>Main Menu</b>\n\nWhat would you like to do?",
        reply_markup=main_menu_kb(),
    )
    await callback.answer()


@router.message(Command("menu"))
async def cmd_menu(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "🏠 <b>Main Menu</b>\n\nWhat would you like to do?",
        reply_markup=main_menu_kb(),
    )
