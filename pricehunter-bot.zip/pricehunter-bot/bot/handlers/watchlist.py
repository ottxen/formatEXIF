from aiogram import Router, F
from aiogram.types import CallbackQuery

from bot.database.models import Database
from bot.keyboards.inline import watchlist_kb, product_actions_kb, main_menu_kb

router = Router()


@router.callback_query(F.data == "menu:watchlist")
async def menu_watchlist(callback: CallbackQuery, db: Database):
    products = await db.get_user_products(callback.from_user.id)

    if not products:
        await callback.message.edit_text(
            "❤️ <b>My Watchlist</b>\n\n"
            "Your watchlist is empty.\n\n"
            "Use <b>🔗 Track by link</b> to add products.",
            reply_markup=main_menu_kb(),
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        f"❤️ <b>My Watchlist</b> ({len(products)})\n\n"
        "Tap a product to manage it:",
        reply_markup=watchlist_kb(products),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("product:"))
async def show_product(callback: CallbackQuery, db: Database):
    product_id = int(callback.data.split(":")[1])
    product = await db.get_product(product_id)

    if not product or product["user_id"] != callback.from_user.id:
        await callback.answer("Product not found", show_alert=True)
        return

    price = product.get("current_price")
    currency = product.get("currency") or "UAH"
    target = product.get("target_price")
    price_str = f"{price:.2f} {currency}" if price is not None else "—"
    target_str = f"{target:.2f} {currency}" if target is not None else "Not set"

    text = (
        f"<b>{product.get('title') or 'Product'}</b>\n\n"
        f"Store: {product.get('store') or '—'}\n"
        f"Current price: <b>{price_str}</b>\n"
        f"Target price: {target_str}\n"
        f"Last checked: {product.get('last_checked') or '—'}\n\n"
        f"<a href='{product['url']}'>Open product page</a>"
    )

    await callback.message.edit_text(
        text,
        reply_markup=product_actions_kb(product_id),
        disable_web_page_preview=False,
    )
    await callback.answer()
