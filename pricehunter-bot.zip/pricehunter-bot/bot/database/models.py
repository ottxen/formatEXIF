from datetime import datetime
from typing import Optional
import aiosqlite


class Database:
    def __init__(self, db_path: str = "./data/bot.db"):
        self.db_path = db_path.replace("sqlite+aiosqlite:///", "")
        self.conn: Optional[aiosqlite.Connection] = None

    async def connect(self):
        self.conn = await aiosqlite.connect(self.db_path)
        self.conn.row_factory = aiosqlite.Row
        await self._create_tables()

    async def close(self):
        if self.conn:
            await self.conn.close()

    async def _create_tables(self):
        await self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                country TEXT,
                region TEXT,
                language TEXT DEFAULT 'en',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                url TEXT NOT NULL,
                title TEXT,
                current_price REAL,
                currency TEXT DEFAULT 'UAH',
                target_price REAL,
                store TEXT,
                image_url TEXT,
                is_active INTEGER DEFAULT 1,
                last_checked TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                price REAL NOT NULL,
                checked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id)
            );

            CREATE INDEX IF NOT EXISTS idx_products_user ON products(user_id);
            CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
            CREATE INDEX IF NOT EXISTS idx_history_product ON price_history(product_id);
        """)
        await self.conn.commit()

    # ---------- Users ----------
    async def upsert_user(self, user_id: int, username: str | None, full_name: str | None):
        await self.conn.execute(
            """
            INSERT INTO users (user_id, username, full_name, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                full_name = excluded.full_name,
                updated_at = excluded.updated_at
            """,
            (user_id, username, full_name, datetime.utcnow().isoformat()),
        )
        await self.conn.commit()

    async def set_user_location(self, user_id: int, country: str, region: str | None = None):
        await self.conn.execute(
            "UPDATE users SET country = ?, region = ?, updated_at = ? WHERE user_id = ?",
            (country, region, datetime.utcnow().isoformat(), user_id),
        )
        await self.conn.commit()

    async def get_user(self, user_id: int) -> dict | None:
        async with self.conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    # ---------- Products ----------
    async def add_product(
        self,
        user_id: int,
        url: str,
        title: str | None,
        price: float | None,
        currency: str = "UAH",
        store: str | None = None,
        image_url: str | None = None,
        target_price: float | None = None,
    ) -> int:
        cursor = await self.conn.execute(
            """
            INSERT INTO products (user_id, url, title, current_price, currency, store, image_url, target_price, last_checked)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                url,
                title,
                price,
                currency,
                store,
                image_url,
                target_price,
                datetime.utcnow().isoformat(),
            ),
        )
        await self.conn.commit()
        product_id = cursor.lastrowid

        if price is not None:
            await self.add_price_history(product_id, price)

        return product_id

    async def get_user_products(self, user_id: int, active_only: bool = True) -> list[dict]:
        query = "SELECT * FROM products WHERE user_id = ?"
        if active_only:
            query += " AND is_active = 1"
        query += " ORDER BY created_at DESC"

        async with self.conn.execute(query, (user_id,)) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def get_product(self, product_id: int) -> dict | None:
        async with self.conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def update_product_price(self, product_id: int, new_price: float):
        await self.conn.execute(
            "UPDATE products SET current_price = ?, last_checked = ? WHERE id = ?",
            (new_price, datetime.utcnow().isoformat(), product_id),
        )
        await self.conn.commit()
        await self.add_price_history(product_id, new_price)

    async def set_target_price(self, product_id: int, target: float | None):
        await self.conn.execute(
            "UPDATE products SET target_price = ? WHERE id = ?",
            (target, product_id),
        )
        await self.conn.commit()

    async def deactivate_product(self, product_id: int, user_id: int) -> bool:
        cursor = await self.conn.execute(
            "UPDATE products SET is_active = 0 WHERE id = ? AND user_id = ?",
            (product_id, user_id),
        )
        await self.conn.commit()
        return cursor.rowcount > 0

    async def get_all_active_products(self) -> list[dict]:
        async with self.conn.execute("SELECT * FROM products WHERE is_active = 1") as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def count_user_products(self, user_id: int) -> int:
        async with self.conn.execute(
            "SELECT COUNT(*) as cnt FROM products WHERE user_id = ? AND is_active = 1",
            (user_id,),
        ) as cursor:
            row = await cursor.fetchone()
            return row["cnt"] if row else 0

    # ---------- Price history ----------
    async def add_price_history(self, product_id: int, price: float):
        await self.conn.execute(
            "INSERT INTO price_history (product_id, price) VALUES (?, ?)",
            (product_id, price),
        )
        await self.conn.commit()

    async def get_price_history(self, product_id: int, limit: int = 30) -> list[dict]:
        async with self.conn.execute(
            """
            SELECT price, checked_at FROM price_history
            WHERE product_id = ?
            ORDER BY checked_at DESC
            LIMIT ?
            """,
            (product_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]
