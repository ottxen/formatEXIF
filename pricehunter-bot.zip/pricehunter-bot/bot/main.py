import asyncio
import logging
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from bot.config import settings
from bot.database.models import Database
from bot.handlers import start, track, categories, watchlist, settings as settings_handler
from bot.services.checker import check_all_products

# Ensure data directory exists
Path("./data").mkdir(exist_ok=True)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger(__name__)


async def main():
    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    # Database
    db = Database()
    await db.connect()
    logger.info("Database connected")

    # Pass db to handlers via workflow_data
    dp["db"] = db

    # Register routers
    dp.include_router(start.router)
    dp.include_router(track.router)
    dp.include_router(categories.router)
    dp.include_router(watchlist.router)
    dp.include_router(settings_handler.router)

    # Middleware-like dependency injection for db
    @dp.update.outer_middleware()
    async def db_middleware(handler, event, data):
        data["db"] = db
        return await handler(event, data)

    # Scheduler for price checks
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        check_all_products,
        "interval",
        minutes=settings.CHECK_INTERVAL_MINUTES,
        kwargs={"bot": bot, "db": db},
        id="price_checker",
        replace_existing=True,
    )
    scheduler.start()
    logger.info(
        "Scheduler started. Price check every %s minutes",
        settings.CHECK_INTERVAL_MINUTES,
    )

    try:
        logger.info("Bot starting...")
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await db.close()
        await bot.session.close()
        logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        import uvloop
        uvloop.install()
    except ImportError:
        pass
    asyncio.run(main())
