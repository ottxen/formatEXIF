from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


# ---------- Countries ----------
COUNTRIES = {
    "UA": "🇺🇦 Ukraine",
    "PL": "🇵🇱 Poland",
    "RO": "🇷🇴 Romania",
    "IT": "🇮🇹 Italy",
    "US": "🇺🇸 USA",
    "DE": "🇩🇪 Germany",
    "FR": "🇫🇷 France",
    "CZ": "🇨🇿 Czech Republic",
}


def countries_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code, name in COUNTRIES.items():
        builder.button(text=name, callback_data=f"country:{code}")
    builder.adjust(2)
    return builder.as_markup()


# ---------- Regions (Ukraine example, others simplified) ----------
REGIONS = {
    "UA": [
        "Kyiv", "Odesa", "Lviv", "Dnipro", "Kharkiv",
        "Vinnytsia", "Zaporizhzhia", "Ivano-Frankivsk",
        "Other region",
    ],
    "PL": ["Warsaw", "Krakow", "Wroclaw", "Gdansk", "Other"],
    "RO": ["Bucharest", "Cluj-Napoca", "Timisoara", "Other"],
    "IT": ["Rome", "Milan", "Naples", "Other"],
    "US": ["New York", "California", "Texas", "Other"],
    "DE": ["Berlin", "Munich", "Hamburg", "Other"],
    "FR": ["Paris", "Lyon", "Marseille", "Other"],
    "CZ": ["Prague", "Brno", "Other"],
}


def regions_kb(country_code: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    regions = REGIONS.get(country_code, ["Other"])
    for region in regions:
        builder.button(text=region, callback_data=f"region:{region}")
    builder.button(text="⬅️ Back", callback_data="back:countries")
    builder.adjust(2)
    return builder.as_markup()


# ---------- Main menu ----------
def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔗 Track by link", callback_data="menu:track")
    builder.button(text="📂 Browse categories", callback_data="menu:categories")
    builder.button(text="❤️ My Watchlist", callback_data="menu:watchlist")
    builder.button(text="⚙️ Settings", callback_data="menu:settings")
    builder.adjust(1)
    return builder.as_markup()


# ---------- Categories tree ----------
CATEGORIES = {
    "electronics": {
        "name": "📱 Electronics",
        "subs": {
            "smartphones": {
                "name": "📱 Smartphones",
                "subs": {
                    "android": "Android Phones",
                    "iphone": "iPhones",
                    "accessories": {
                        "name": "🔌 Accessories",
                        "items": [
                            ("cases", "🛡️ Cases"),
                            ("chargers", "🔌 Chargers & Cables"),
                            ("protectors", "🛡️ Screen Protectors"),
                            ("powerbanks", "🔋 Power Banks"),
                            ("earphones", "🎧 Earphones"),
                        ],
                    },
                },
            },
            "laptops": {
                "name": "💻 Laptops & PCs",
                "subs": {
                    "laptops": "Laptops",
                    "desktops": "Desktop PCs",
                    "monitors": "Monitors",
                    "components": "Components",
                    "peripherals": "Keyboards & Mice",
                },
            },
            "tablets": "📱 Tablets",
            "tvs": "📺 TVs",
            "audio": "🎧 Audio",
            "cameras": "📷 Cameras & Drones",
            "wearables": "⌚ Wearables",
            "large_appliances": "🧊 Large Appliances",
            "small_appliances": "🍳 Small Appliances",
        },
    },
    "jewelry": {
        "name": "💎 Jewelry & Accessories",
        "subs": {
            "rings": "💍 Rings",
            "necklaces": "📿 Necklaces",
            "earrings": "👂 Earrings",
            "watches": "⌚ Watches",
            "sunglasses": "🕶️ Sunglasses",
            "bags": "👜 Bags & Wallets",
        },
    },
    "food": {
        "name": "🍔 Food & Grocery",
        "subs": {
            "coffee": "☕ Coffee & Tea",
            "sweets": "🍫 Sweets & Snacks",
            "dairy": "🥛 Dairy",
            "meat": "🥩 Meat & Fish",
            "alcohol": "🍷 Alcohol",
        },
    },
    "fashion": {
        "name": "👕 Fashion",
        "subs": {
            "men": "👔 Men",
            "women": "👗 Women",
            "kids": "👶 Kids",
            "shoes": "👟 Shoes",
            "bags": "👜 Bags",
        },
    },
    "home": {
        "name": "🏠 Home & Garden",
        "subs": {
            "furniture": "🛋️ Furniture",
            "bedding": "🛏️ Bedding",
            "kitchen": "🍽️ Kitchenware",
            "cleaning": "🧹 Cleaning",
            "garden": "🪴 Garden",
            "lighting": "💡 Lighting",
        },
    },
    "gaming": {
        "name": "🎮 Gaming",
        "subs": {
            "consoles": "🎮 Consoles",
            "games": "🎯 Games",
            "controllers": "🕹️ Controllers",
            "chairs": "💺 Gaming Chairs",
            "headsets": "🎧 Headsets",
        },
    },
    "kids": {
        "name": "👶 Kids & Baby",
        "subs": {
            "feeding": "🍼 Feeding",
            "clothes": "👕 Clothes",
            "toys": "🧸 Toys",
            "strollers": "🚗 Strollers",
        },
    },
    "auto": {
        "name": "🚗 Auto & Moto",
        "subs": {
            "oils": "🛢️ Oils & Fluids",
            "batteries": "🔋 Batteries",
            "tools": "🛠️ Tools",
            "accessories": "🚗 Accessories",
        },
    },
    "beauty": {
        "name": "💄 Beauty & Health",
        "subs": {
            "skincare": "🧴 Skincare",
            "makeup": "💄 Makeup",
            "hair": "💇 Hair Care",
            "vitamins": "💊 Vitamins",
        },
    },
    "sports": {
        "name": "🏀 Sports & Outdoors",
        "subs": {
            "running": "🏃 Running",
            "fitness": "🏋️ Fitness",
            "cycling": "🚴 Cycling",
            "camping": "🏕️ Camping",
        },
    },
    "books": {
        "name": "📚 Books & Stationery",
        "subs": {
            "books": "📖 Books",
            "stationery": "✏️ Stationery",
            "backpacks": "🎒 Backpacks",
        },
    },
    "pets": {
        "name": "🐾 Pets",
        "subs": {
            "dogs": "🐶 Dogs",
            "cats": "🐱 Cats",
            "other": "🐹 Small Pets",
        },
    },
}


def categories_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, data in CATEGORIES.items():
        name = data["name"] if isinstance(data, dict) else data
        builder.button(text=name, callback_data=f"cat:{key}")
    builder.button(text="⬅️ Main Menu", callback_data="menu:main")
    builder.adjust(2)
    return builder.as_markup()


def subcategories_kb(cat_key: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    cat = CATEGORIES.get(cat_key)
    if not cat or not isinstance(cat, dict):
        return main_menu_kb()

    subs = cat.get("subs", {})
    for sub_key, sub_data in subs.items():
        if isinstance(sub_data, dict):
            name = sub_data.get("name", sub_key)
        else:
            name = sub_data
        builder.button(text=name, callback_data=f"sub:{cat_key}:{sub_key}")

    builder.button(text="⬅️ Back", callback_data="menu:categories")
    builder.button(text="🏠 Main Menu", callback_data="menu:main")
    builder.adjust(2)
    return builder.as_markup()


def items_kb(cat_key: str, sub_key: str) -> InlineKeyboardMarkup:
    """Third level (e.g. Accessories under Smartphones)"""
    builder = InlineKeyboardBuilder()
    cat = CATEGORIES.get(cat_key, {})
    subs = cat.get("subs", {}) if isinstance(cat, dict) else {}
    sub = subs.get(sub_key, {})

    if isinstance(sub, dict) and "items" in sub:
        for item_key, item_name in sub["items"]:
            builder.button(text=item_name, callback_data=f"item:{cat_key}:{sub_key}:{item_key}")
        builder.button(text="🔍 Type product name", callback_data=f"search:{cat_key}:{sub_key}")
    else:
        # No deeper level — go to search
        builder.button(text="🔍 Type product name", callback_data=f"search:{cat_key}:{sub_key}")

    builder.button(text="⬅️ Back", callback_data=f"cat:{cat_key}")
    builder.button(text="🏠 Main Menu", callback_data="menu:main")
    builder.adjust(2)
    return builder.as_markup()


def watchlist_kb(products: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in products:
        title = (p.get("title") or "Unknown")[:40]
        price = p.get("current_price")
        currency = p.get("currency") or "UAH"
        price_str = f"{price:.0f} {currency}" if price is not None else "—"
        builder.button(
            text=f"{title} • {price_str}",
            callback_data=f"product:{p['id']}",
        )
    builder.button(text="⬅️ Main Menu", callback_data="menu:main")
    builder.adjust(1)
    return builder.as_markup()


def product_actions_kb(product_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🎯 Set target price", callback_data=f"target:{product_id}")
    builder.button(text="🔄 Check now", callback_data=f"check:{product_id}")
    builder.button(text="🗑 Remove", callback_data=f"remove:{product_id}")
    builder.button(text="⬅️ Watchlist", callback_data="menu:watchlist")
    builder.adjust(2)
    return builder.as_markup()


def back_to_main_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="⬅️ Main Menu", callback_data="menu:main")
    return builder.as_markup()


def confirm_remove_kb(product_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Yes, remove", callback_data=f"confirm_remove:{product_id}")
    builder.button(text="❌ Cancel", callback_data=f"product:{product_id}")
    builder.adjust(2)
    return builder.as_markup()
