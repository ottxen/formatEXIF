import logging
from aiogram import Bot

from bot.database.models import Database
from bot.services.parser import parse_product

logger = logging.getLogger(__name__)


async def check_all_products(bot: Bot, db: Database):
    """Background job: check prices of all active products and notify users."""
    products = await db.get_all_active_products()
    logger.info("Starting price check for %d products", len(products))

    for product in products:
        try:
            parsed = await parse_product(product["url"])
            if parsed.price is None:
                logger.warning("Could not parse price for product %s", product["id"])
                continue

            old_price = product["current_price"]
            new_price = parsed.price

            # Update title if we got a better one
            if parsed.title and parsed.title != "Unknown product":
                # We only update price for simplicity; title update can be added later
                pass

            await db.update_product_price(product["id"], new_price)

            # Notify on drop
            if old_price is not None and new_price < old_price:
                drop = old_price - new_price
                percent = (drop / old_price) * 100 if old_price else 0
                text = (
                    f"📉 <b>Price drop!</b>\n\n"
                    f"<b>{product.get('title') or 'Product'}</b>\n"
                    f"Store: {product.get('store') or '—'}\n\n"
                    f"Old: <s>{old_price:.2f} {product.get('currency', 'UAH')}</s>\n"
                    f"New: <b>{new_price:.2f} {product.get('currency', 'UAH')}</b>\n"
                    f"You save: {drop:.2f} ({percent:.1f}%)\n\n"
                    f"<a href='{product['url']}'>Open product</a>"
                )
                try:
                    await bot.send_message(
                        product["user_id"],
                        text,
                        disable_web_page_preview=False,
                    )
                except Exception as e:
                    logger.error("Failed to notify user %s: %s", product["user_id"], e)

            # Target price reached
            target = product.get("target_price")
            if target is not None and new_price <= target:
                text = (
                    f"🎯 <b>Target price reached!</b>\n\n"
                    f"<b>{product.get('title') or 'Product'}</b>\n"
                    f"Current price: <b>{new_price:.2f} {product.get('currency', 'UAH')}</b>\n"
                    f"Your target: {target:.2f}\n\n"
                    f"<a href='{product['url']}'>Open product</a>"
                )
                try:
                    await bot.send_message(product["user_id"], text)
                except Exception as e:
                    logger.error("Failed to notify user %s: %s", product["user_id"], e)

        except Exception as e:
            logger.exception("Error checking product %s: %s", product.get("id"), e)

    logger.info("Price check finished")
