"""
Simple product page parser.
For production you should expand store-specific parsers
and consider Playwright for heavily protected sites (Rozetka).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup


@dataclass
class ParsedProduct:
    title: Optional[str]
    price: Optional[float]
    currency: str
    store: str
    image_url: Optional[str]
    available: bool = True


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/130.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7",
}


def detect_store(url: str) -> str:
    host = urlparse(url).netloc.lower()
    if "rozetka" in host:
        return "Rozetka"
    if "allo.ua" in host or "allo." in host:
        return "Allo"
    if "comfy.ua" in host:
        return "Comfy"
    if "amazon." in host:
        return "Amazon"
    if "allegro." in host:
        return "Allegro"
    if "prom.ua" in host:
        return "Prom"
    if "olx." in host:
        return "OLX"
    if "foxtrot.com.ua" in host:
        return "Foxtrot"
    if "moyo.ua" in host:
        return "MOYO"
    return "Unknown"


def _extract_price(text: str) -> Optional[float]:
    if not text:
        return None
    # Remove spaces and common separators, keep digits and dot/comma
    cleaned = re.sub(r"[^\d.,]", "", text.replace("\xa0", "").replace(" ", ""))
    cleaned = cleaned.replace(",", ".")
    # Take the first reasonable number
    match = re.search(r"(\d+\.?\d*)", cleaned)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            return None
    return None


async def parse_product(url: str) -> ParsedProduct:
    store = detect_store(url)
    title = None
    price = None
    currency = "UAH"
    image_url = None

    try:
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True, headers=HEADERS) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            html = resp.text
    except Exception:
        return ParsedProduct(
            title="Could not fetch page",
            price=None,
            currency=currency,
            store=store,
            image_url=None,
            available=False,
        )

    soup = BeautifulSoup(html, "lxml")

    # Generic OpenGraph / meta
    og_title = soup.find("meta", property="og:title")
    if og_title and og_title.get("content"):
        title = og_title["content"].strip()

    if not title:
        t = soup.find("title")
        if t:
            title = t.get_text(strip=True)

    og_image = soup.find("meta", property="og:image")
    if og_image and og_image.get("content"):
        image_url = og_image["content"]

    # Try common price selectors / meta
    price_meta = soup.find("meta", property="product:price:amount")
    if price_meta and price_meta.get("content"):
        price = _extract_price(price_meta["content"])

    if not price:
        # JSON-LD
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                import json
                data = json.loads(script.string or "")
                if isinstance(data, dict):
                    offers = data.get("offers")
                    if isinstance(offers, dict):
                        price = _extract_price(str(offers.get("price", "")))
                        currency = offers.get("priceCurrency", currency)
                    elif isinstance(offers, list) and offers:
                        price = _extract_price(str(offers[0].get("price", "")))
                        currency = offers[0].get("priceCurrency", currency)
                if price:
                    break
            except Exception:
                continue

    # Store-specific light heuristics
    if store == "Rozetka" and not price:
        price_el = soup.select_one("[class*='price'], .product-price__big, .price")
        if price_el:
            price = _extract_price(price_el.get_text())

    if store == "Allo" and not price:
        price_el = soup.select_one(".sum, .price__main, [class*='price']")
        if price_el:
            price = _extract_price(price_el.get_text())

    if "amazon." in urlparse(url).netloc:
        currency = "USD" if ".com" in url else "EUR"
        price_el = soup.select_one(".a-price .a-offscreen, #priceblock_ourprice, .a-price-whole")
        if price_el:
            price = _extract_price(price_el.get_text())

    return ParsedProduct(
        title=title[:300] if title else "Unknown product",
        price=price,
        currency=currency,
        store=store,
        image_url=image_url,
        available=price is not None,
    )
