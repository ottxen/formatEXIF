# PriceHunter — Telegram Price Tracker Bot

Simple and practical Telegram bot that tracks product prices from online stores and notifies you when the price drops.

## Features

- 🌍 Country & region selection (UA, PL, DE, US, etc.)
- 🔗 Track any product by link (Rozetka, Allo, Comfy, Amazon, Allegro…)
- 📂 Category browser (guided search helper)
- ❤️ Personal Watchlist
- 🎯 Target price alerts
- 📉 Automatic price-drop notifications
- 🔄 Manual “Check now” button
- Fully in **English**
- Inline buttons only

## Tech Stack

- Python 3.12
- aiogram 3
- aiosqlite
- APScheduler
- httpx + BeautifulSoup (light parser)

## Quick Start (local)

```bash
git clone <your-repo>
cd pricehunter-bot

python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env
# Edit .env and put your BOT_TOKEN
```

Get a token from [@BotFather](https://t.me/BotFather).

Run:

```bash
python -m bot.main
```

## Deploy on Railway

1. Push this repository to GitHub.
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub repo.
3. Add environment variable:
   - `BOT_TOKEN` = your token from BotFather
4. (Optional)
   - `CHECK_INTERVAL_MINUTES` = `180` (default 3 hours)
   - `LOG_LEVEL` = `INFO`
5. Deploy.

Railway will detect the `Dockerfile` and start the bot.

### Persistent storage (recommended)

SQLite file lives in `/app/data/bot.db`.  
On Railway free/hobby plans the filesystem can be ephemeral.  
For production attach a **Volume** mounted at `/app/data`.

## Project structure

```
pricehunter-bot/
├── bot/
│   ├── main.py              # Entry point
│   ├── config.py
│   ├── handlers/            # start, track, categories, watchlist, settings
│   ├── keyboards/           # All inline keyboards + category tree
│   ├── states/              # FSM states
│   ├── services/            # Parser + price checker
│   └── database/            # SQLite models
├── data/                    # SQLite database (created automatically)
├── Dockerfile
├── requirements.txt
├── .env.example
└── README.md
```

## How the bot works

1. User presses `/start` → selects country → region.
2. **Track by link** — paste product URL → bot saves title + price.
3. Background job checks prices every N minutes.
4. If price drops or target is reached → user gets a Telegram notification.
5. Categories help the user formulate a search, then guide them to paste a real product link (most reliable method).

## Supported stores (basic parsing)

Works best with pages that have proper OpenGraph / JSON-LD:

- Rozetka
- Allo
- Comfy
- Amazon
- Allegro
- Prom.ua
- others with standard meta tags

Heavily protected sites may need Playwright later.

## Commands

- `/start` — start / show main menu
- `/menu` — open main menu

## License

MIT — do whatever you want.
